To configure departments, you need to:

* Go to *Contacts > Configuration > Departments*.

.. figure:: path/to/local/image.png
   :alt: alternative description
   :width: 600 px
