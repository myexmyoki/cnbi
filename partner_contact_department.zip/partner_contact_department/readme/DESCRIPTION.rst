This module extends the functionality of the address book to support
departments.

Department is a drop-down field in partner forms, and it refers to contact
department in its own company.
