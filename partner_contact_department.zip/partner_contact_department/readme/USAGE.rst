To use this module, you need to:

* Go to any partner's form.
* You will find the new *Department* field below *Job Position*.
