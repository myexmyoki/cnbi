This module was written to define natural day option in request unit on holidays type.
