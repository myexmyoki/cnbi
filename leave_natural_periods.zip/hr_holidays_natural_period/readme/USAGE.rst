For using natural period on leaves:

#. Go to *Leaves > Dashboard*.
#. Select dragging on the calendar the days you want to be on leave, or go
   to the form view for selecting start and end dates.
#. Select the proper "Leave Type" that has "Natural day" selected in "Request unit".
#. If no leave type is yet specified, then default configuration is to exclude
   public holidays.
#. The number of days will be computed without employee calendar used.
