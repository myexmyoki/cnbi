This module allows to attach documents to the employee profile.
