# -*- coding: utf-8 -*-
{
    'name': 'Button For Database Manager',
    'version': '1.0',
    'summary': """Adding new button to access database manager.""",
    'description': """Adding new button to access database manager.""",
    'category': 'Base',
    'author': 'iKreative',
    'website': "",
    'license': 'AGPL-3',

    'depends': ['base'],

    'data': [
    ],
    'demo': [

    ],
    'images': ['static/description/banner.png'],
    'qweb': [
        'static/src/xml/menu.xml',
    ],

    'installable': True,
    'auto_install': False,
    'application': False,
}
