The following keyboard shortcuts are implemented:

* Toggle app drawer - ``Alt + Shift + A``
* Navigate app search results - Arrow keys
* Choose app result - ``Enter``
* ``Esc`` to close app drawer


Also you can access to the user menu, with ``Alt + Shift + U``
