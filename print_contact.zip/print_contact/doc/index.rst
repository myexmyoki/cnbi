==============
print_contact
==============

This module is usefull to print the list of your contacts, check-in reports or full-pages that describe your clients.

Usage
=====
Go to "Settings" - Apps without any filters. Type "print_contact" into the search box.

Odoo version 13

Credits
=======

Authors
~~~~~~~

* Yvan Dotet

Maintainers
~~~~~~~~~~~

* This module is maintained by Yvan Dotet.

Contact
~~~~~~~

* Mail address of Yvan Dotet : Yvandotet@yahoo.fr
* website : 
	1) https://github.com/YvanDotet/print_contact
	2) https://be.linkedin.com/in/yvan-dotet-19ba67135
