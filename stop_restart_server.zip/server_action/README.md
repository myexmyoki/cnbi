Odoo server Action
------------------

Version
--------
Odoo 13.0

Notes
--------
This module will work with Direct SSH connection(without private key and Openvpn).


Packages
----------
-> pexpect: sudo pip install pexpect

Configuration
--------------
-> Only users with access right to "Server Action" can manage server actions. 
   Settings > Users > Other > Server action
-> Add list of server details 


A Smart User Interface
----------------------

Using odoo interface it you can connect through with one click ans start and stop client serevr.

A Better Way To Work – Together
-------------------------------

No use of terminal odoo will directly connect and manage server action.

Add Server details
--------------------------

You can add list of server details and also no need to manage in text file in odoo itself you will add server details

Maintain history
---------------------------------------------

All the server action are perform will manage through history.


Manage Groups
-------------------------------

Separate user groups for manage server action so it will be easy to give access to perticular user for manage server action


