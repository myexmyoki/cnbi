Requirements and exceptions
===========================
* To start using this module you have to install following python package in your system
	->  pexpect: sudo pip install pexpect
