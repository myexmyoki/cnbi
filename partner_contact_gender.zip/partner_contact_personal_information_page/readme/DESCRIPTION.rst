This module extends the contact management functionality.

Its only purpose is to serve as a base for other modules that add personal
information fields to **contacts that are persons**.
