You can find a new page called *Personal Information* in the contact's form.
