New item for 'Gender' can be edited on the 'Personal Information' tab of
the partner contact form.
