This module extends the contact management functionality. It allows recording
of a partner's gender.
