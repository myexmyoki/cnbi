## Module <hr_payslip_monthly_report>

#### 29.2.2020
#### Version 13.0.1.0.0
#### ADD
- Initial commit

